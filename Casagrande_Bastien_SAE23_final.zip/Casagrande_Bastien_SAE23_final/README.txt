FONCTIONNEMENT : 

Lancer "appliWeb" et une demande de création de base de donnée sera créée et remplie.
À chaque redémarrage du serveur, les données implémentées seront supprimées et seules
resteront les données des fichiers CSV. (implémentation de base)
Pour créer base vide, utiliser le CLI qui permet de supprimer toutes les données d'une table ou à partir du 
fichier "appliWeb", supprimer les lignes "MettreDonneesFleurs()" et "MettreDonneesLieu()"



Affichages fonctionne que pour une seule table (2 normalement)
Insertion fonctionnelle 
Suppression fonctionnelle
Partie publique non complétée 


Le serveur se lance à l'aide du fichier configDBcours.txt de base (localhost admin admin)

Dans le dossier tamp est l'équivalent du dossier 'res'. Il y a tous les fichiers de police d'écriture,
html, css et bootstraps javascript présents dedans.


L'application s'ouvre de base avec le lien http://localhost:8080



