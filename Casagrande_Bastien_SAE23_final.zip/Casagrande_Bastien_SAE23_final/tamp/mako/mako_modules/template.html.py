# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686086849.6981995
_enable_loop = True
_template_filename = 'tamp/templates/template.html'
_template_uri = 'template.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        self = context.get('self', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\n<html lang="fr">\n<head>\n\t<title>Mon site Internet</title>\n\t<meta charset="UTF-8">\n\t<meta name="viewport" content="width=device-width, initial-scale=1">\n<!--===============================================================================================-->\t\n<link rel="icon" type="image/png" href="/static/images/icons/favicon.ico"/>\n<!--===============================================================================================-->\n\t<link rel="stylesheet" type="text/css" href="/static/vendor/bootstrap/css/bootstrap.min.css">\n<!--===============================================================================================-->\n\t<link rel="stylesheet" type="text/css" href="/static/fonts/font-awesome-4.7.0/css/font-awesome.min.css">\n<!--===============================================================================================-->\n\t<link rel="stylesheet" type="text/css" href="/static/vendor/animate/animate.css">\n<!--===============================================================================================-->\n\t<link rel="stylesheet" type="text/css" href="/static/vendor/select2/select2.min.css">\n<!--===============================================================================================-->\n\t<link rel="stylesheet" type="text/css" href="/static/css/util.css">\n\t<link rel="stylesheet" type="text/css" href="/static/css/main.css">\n\t<link rel="stylesheet" href="/static/css/bootstrap.min.css" >\n\n\n\t<script src="/static/js/jquery-3.5.0.min.js"></script>\n    <script src="/static/js/bootstrap.min.js"></script>\n<!--===============================================================================================-->\n</head>\n<body>\n\t<!--  -->\n\t<div class="simpleslide100">\n\t\t<div class="simpleslide100-item bg-img1" style="background-image: url(\'/static/images/bg06.jpg\');"></div>\n\t\t<div class="simpleslide100-item bg-img1" style="background-image: url(\'/static/images/bg05.jpg\');"></div>\n\t\t<div class="simpleslide100-item bg-img1" style="background-image: url(\'/static/images/bg04.jpg\');"></div>\n\t</div>\n\n\t<div class="size1 overlay1">\n\t\t<!--  -->\n\t\t<div class="w-full flex-w flex-sb-m p-l-65 p-r-80 p-t-22 p-b-185 p-lr-15-sm respon8 ">\n\t\t\t<div class="wrappic1 m-r-30 m-t-10 m-b-10">\n\t\t\t\t<a href="index"><img src="/static/images/icons/logo.png" alt="LOGO" width="55" height="31"></a>\n\t\t\t</div>\n\t\t\t\n\t\t\t\n\t\t\t\n\t\t\t<nav class="navbar navbar-expand-lg flex-w m-t-10 m-b-10 size2 m1-txt1 flex-c-m how-btn1">\n\t\t\t\t<div class="collapse navbar-collapse" id="navbarNavDropdown">\n\t\t\t\t <ul class="navbar-nav">\n\n\t\t\t\t   <li class="nav-item dropdown">\n\t\t\t\t\t <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">\n\t\t\t\t\t   Affichages\n\t\t\t\t\t </a>\n\t\t\t\t\t <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">\n\t\t\t\t\t\t<a class="dropdown-item" href="affParOrdre">Par ordre</a>\n\t\t\t\t\t\t<a class="dropdown-item" href="affParNum">Par numéro</a>\n\t\t\t\t\t </div>\n\t\t\t\t   </li>\n\t\t\t\t   <li class="nav-item">\n\t\t\t\t\t <a class="nav-link" href="insertPage">Insertion</a>\n\t\t\t\t   </li>\n\t\t\t\t   <li class="nav-item">\n\t\t\t\t\t <a class="nav-link" href="suppressById">Supression</a>\n\t\t\t\t   </li>\n\t\t\t\t   <li class="nav-item">\n\t\t\t\t\t<a class="nav-link" href="insertEvent">Évènement</a>\n\t\t\t\t  </li>\n\t\t\t\t </ul>\n\t\t\t   </div>\n\t\t\t</nav>\n\t\t</div>\n\n\t\t<!--  -->\n\n    \n\n        ')
        __M_writer(str( self.body() ))
        __M_writer('\n\n\n\t\t\t\n\t</div>\n\n\n\n\t\n\n<!--===============================================================================================-->\t\n\t<script src="/static/templates/vendor/jquery/jquery-3.2.1.min.js"></script>\n<!--===============================================================================================-->\n<!--\t<script src="vendor/bootstrap/js/popper.js"></script>\t-->\n<!--\t<script src="vendor/bootstrap/js/bootstrap.min.js"></script>\t-->\n<!--===============================================================================================-->\n<!--\t<script src="vendor/select2/select2.min.js"></script>  --> <!--Snippet Javascript-->\n\n<!--===============================================================================================-->\n<!--\t<script src="vendor/tilt/tilt.jquery.min.js"></script>\n\t<script >\n\t\t$(\'.js-tilt\').tilt({\n\t\t\tscale: 3\n\t\t})\n\t</script>   --> <!-- Code bizarre pour rendre certains visuels plus attrayants -->\n<!--===============================================================================================-->\n\t<script src="/static/templates/js/main.js"></script>  \n\n</body>\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "tamp/templates/template.html", "uri": "template.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 75, "24": 75, "30": 24}}
__M_END_METADATA
"""
