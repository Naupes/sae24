# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686088676.5072875
_enable_loop = True
_template_filename = 'tamp/templates/insert.html'
_template_uri = 'insert.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        __M_writer('\n\n\n<pre class="center m2-txt1 l1-txt2 p-b-30 p-l-58">\nInsertions\n</pre>\n \n<pre class="m2-txt1 p-l-20">\nInsertions de données contenues dans la base "fleur".\n</pre>\n\n <form action="insertDone" method="POST" class="needs-validation" novalidate>\n  <div class="form-group">\n    <label class="m2-txt1" for="nbFleur">Numéro fleur :</label>\n    <input type="text" class="form-control" id="nbFleur" placeholder="Entrer le numéro" name="nbFleur" required>\n    <div class="valid-feedback ">Valid.</div>\n    <div class="invalid-feedback">Remplir ce champ, SVP!</div>\n  </div>\n  <div class="form-group">\n    <label class="m2-txt1" for="couleur">Couleur (rouge,vert,bleu...) :</label>\n    <input type="text" class="form-control" id="couleur" placeholder="Entrer la couleur" name="couleur" required>\n    <div class="valid-feedback">Valid.</div>\n    <div class="invalid-feedback">Remplir ce champ, SVP!</div>\n  </div>\n  <div class="form-group">\n    <label class="m2-txt1" for="nom">Nom:</label>\n    <input type="text" class="form-control" id="nom" placeholder="Entrer le nom" name="nom" required>\n    <div class="valid-feedback">Valid.</div>\n    <div class="invalid-feedback">Remplir ce champ, SVP!</div>\n  </div>\n  <div class="form-group">\n    <label class="m2-txt1" for="petales">Nombre de pétales :</label>\n    <input type="text" class="form-control" id="petales" placeholder="Entrer le nombre de pétales" name="petales" required>\n    <div class="valid-feedback ">Valid.</div>\n    <div class="invalid-feedback">Remplir ce champ, SVP!</div>\n  </div>\n  <div class="form-group">\n    <label class="m2-txt1" for="taille">Taille :</label>\n    <input type="text" class="form-control" id="taille" placeholder="Entrer la taille" name="taille" required>\n    <div class="valid-feedback ">Valid.</div>\n    <div class="invalid-feedback">Remplir ce champ, SVP!</div>\n  </div>\n  <div class="form-group">\n    <label class="m2-txt1" for="typetige">Entrez le type de tige (fine, épineuse...):</label>\n    <input type="text" class="form-control" id="typetige" placeholder="Entrer la caractéristique de la tige" name="typetige" required>\n    <div class="valid-feedback ">Valid.</div>\n    <div class="invalid-feedback">Remplir ce champ, SVP!</div>\n  </div>\n  \n  <div class="form-group">\n    <l-abel class="form">\n    <label class="m2-txt1" for="eclosion">Date de l\'éclosion de la plante :</label>\n    <input type="date" class="form-control" id="eclosion" placeholder="Date de l\'éclosion" name="eclosion" required>\n    </label>\n  </div>\n\n  <div class="form-group">\n    <label class="m2-txt1" for="saison">Entrez la saison (Printemps, Ete, Automne, Hiver):</label>\n    <input type="text" class="form-control" id="saison" placeholder="Entrer saison" name="saison" required>\n    <div class="valid-feedback ">Valid.</div>\n    <div class="invalid-feedback">Remplir ce champ, SVP!</div>\n  </div>\n  <button type="submit" class="btn btn-primary">Insérer</button>\n</form>\n\n\n\n\n\n<script>\n(function() {\n  \'use strict\';\n  window.addEventListener(\'load\', function() {\n    // Get the forms we want to add validation styles to\n    var forms = document.getElementsByClassName(\'needs-validation\');\n    // Loop over them and prevent submission\n    var validation = Array.prototype.filter.call(forms, function(form) {\n      form.addEventListener(\'submit\', function(event) {\n        if (form.checkValidity() === false) {\n          event.preventDefault();\n          event.stopPropagation();\n        }\n        form.classList.add(\'was-validated\');\n      }, false);\n    });\n  }, false);\n})();\n</script> \n\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "tamp/templates/insert.html", "uri": "insert.html", "source_encoding": "utf-8", "line_map": {"27": 0, "32": 1, "38": 32}}
__M_END_METADATA
"""
