# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686086186.9728904
_enable_loop = True
_template_filename = 'tamp/templates/affich_num.html'
_template_uri = 'affich_num.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        mesFleurs = context.get('mesFleurs', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n\r\n<h3 class="center m2-txt1 l1-txt2 p-b-30 p-l-58">Affichage</h3>\r\n\r\n<pre class="m2-txt1 p-l-20">\r\nAffichage des données contenues dans la base.\r\n\r\n</pre>\r\n<h3 class="m2-txt1 p-l-20">Liste des Fleurs par numéro:</h3>\r\n<div class="conteneur">\r\n')
        for e in mesFleurs:
            __M_writer('    <div class="m2-txt1 caseblanche"> ')
            __M_writer(str(e))
            __M_writer(' </div>\r\n')
        __M_writer('</div>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "tamp/templates/affich_num.html", "uri": "affich_num.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 12, "35": 13, "36": 13, "37": 13, "38": 15, "44": 38}}
__M_END_METADATA
"""
